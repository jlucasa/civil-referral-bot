const {google} = require('googleapis');

const SCOPE = ['https://www.googleapis.com/auth/spreadsheets'];

exports.handleNewUnsubscriber = async (req, res) => {
    const emailAddress = req.body.data.merges['EMAIL'];

    const jwt = getJwt();
    const apiKey = getApiKey();
    const spreadsheetId = process.env.SHEETID;
    const range = 'Testing Sheet!A1';

    const updatedDate = new Date().toISOString().
        replace(/T/, ' ').      // replace T with a space
        replace(/\..+/, '')     // delete the dot and everything after
    
    
    let results = undefined;

    try {
        results = await getAllRows(jwt, apiKey, spreadsheetId);
    } catch (err) {
        return res.status(404).type('text/plain').send(`An error occurred: ${err}`);
    }

    if (results !== undefined) {
        console.log(results);
        return res.status(200).type('application/json').send(results);
    }

    return res.status(500).type('text/plain').send('An unknown error occurred');
}

function getJwt() {
    const credentials = require('./credentials.json');
    return new google.auth.JWT(
        credentials.client_email, 
        null,
        credentials.private_key,
        SCOPE
    )
}

function getApiKey() {
    return require('./apikey.json').key;
}

async function getAllRows(jwt, apiKey, spreadsheetId) {
    const sheets = google.sheets('v4');
    try {
        const results = await sheets.spreadsheets.get({
            spreadsheetId: spreadsheetId,
            auth: jwt,
            key: apiKey,
            fields: ['EMAIL_ADDRESS']
        });

        return results.data;
    } catch (err) {
        throw err;
    }
}